﻿namespace Group_AJR___SBC_Booking_System.checkin
{
    partial class checkinform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(checkinform));
            this.label1 = new System.Windows.Forms.Label();
            this.cusidtxtbox = new System.Windows.Forms.TextBox();
            this.cusidsearch = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Result = new System.Windows.Forms.Label();
            this.resultfound = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.customeridbox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkin = new System.Windows.Forms.Button();
            this.checkinornot = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(25, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search by Customer ID: ";
            // 
            // cusidtxtbox
            // 
            this.cusidtxtbox.Location = new System.Drawing.Point(211, 32);
            this.cusidtxtbox.Name = "cusidtxtbox";
            this.cusidtxtbox.Size = new System.Drawing.Size(225, 30);
            this.cusidtxtbox.TabIndex = 1;
            // 
            // cusidsearch
            // 
            this.cusidsearch.Location = new System.Drawing.Point(454, 26);
            this.cusidsearch.Name = "cusidsearch";
            this.cusidsearch.Size = new System.Drawing.Size(96, 39);
            this.cusidsearch.TabIndex = 2;
            this.cusidsearch.Text = "Search";
            this.cusidsearch.UseVisualStyleBackColor = true;
            this.cusidsearch.Click += new System.EventHandler(this.cusidsearch_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(22, 162);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(666, 191);
            this.dataGridView1.TabIndex = 6;
            // 
            // Result
            // 
            this.Result.AutoSize = true;
            this.Result.BackColor = System.Drawing.Color.Transparent;
            this.Result.Font = new System.Drawing.Font("Gill Sans MT Condensed", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.Location = new System.Drawing.Point(299, 115);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(67, 35);
            this.Result.TabIndex = 7;
            this.Result.Text = "Result";
            // 
            // resultfound
            // 
            this.resultfound.AutoSize = true;
            this.resultfound.BackColor = System.Drawing.Color.Transparent;
            this.resultfound.Location = new System.Drawing.Point(206, 74);
            this.resultfound.Name = "resultfound";
            this.resultfound.Size = new System.Drawing.Size(228, 25);
            this.resultfound.TabIndex = 8;
            this.resultfound.Text = "[...................................................]";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(113, 429);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Customer ID: ";
            // 
            // customeridbox2
            // 
            this.customeridbox2.Location = new System.Drawing.Point(228, 426);
            this.customeridbox2.Name = "customeridbox2";
            this.customeridbox2.Size = new System.Drawing.Size(225, 30);
            this.customeridbox2.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Gill Sans MT Condensed", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(241, 378);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 35);
            this.label3.TabIndex = 11;
            this.label3.Text = "Check-In Customer";
            // 
            // checkin
            // 
            this.checkin.Location = new System.Drawing.Point(510, 419);
            this.checkin.Name = "checkin";
            this.checkin.Size = new System.Drawing.Size(96, 39);
            this.checkin.TabIndex = 12;
            this.checkin.Text = "Check-in Customer";
            this.checkin.UseVisualStyleBackColor = true;
            this.checkin.Click += new System.EventHandler(this.checkin_Click);
            // 
            // checkinornot
            // 
            this.checkinornot.AutoSize = true;
            this.checkinornot.BackColor = System.Drawing.Color.Transparent;
            this.checkinornot.Location = new System.Drawing.Point(223, 469);
            this.checkinornot.Name = "checkinornot";
            this.checkinornot.Size = new System.Drawing.Size(228, 25);
            this.checkinornot.TabIndex = 13;
            this.checkinornot.Text = "[...................................................]";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Location = new System.Drawing.Point(467, 425);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(37, 29);
            this.checkBox1.TabIndex = 14;
            this.checkBox1.Text = "-";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(228, 510);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(232, 56);
            this.button1.TabIndex = 15;
            this.button1.Text = "Exit ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkinform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(708, 576);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.checkinornot);
            this.Controls.Add(this.checkin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.customeridbox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.resultfound);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cusidsearch);
            this.Controls.Add(this.cusidtxtbox);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Gill Sans MT Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.Name = "checkinform";
            this.Text = "Check-In Form";
            this.Load += new System.EventHandler(this.checkinform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox cusidtxtbox;
        private System.Windows.Forms.Button cusidsearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.Label resultfound;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox customeridbox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button checkin;
        private System.Windows.Forms.Label checkinornot;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
    }
}