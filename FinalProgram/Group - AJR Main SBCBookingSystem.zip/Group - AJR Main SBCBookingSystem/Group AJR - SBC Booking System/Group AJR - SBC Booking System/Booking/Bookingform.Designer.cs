﻿namespace Group_AJR___SBC_Booking_System.Booking
{
    partial class Bookingform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bookingform));
            this.AvLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.idBox = new System.Windows.Forms.TextBox();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.checkId = new System.Windows.Forms.Button();
            this.checkEmail = new System.Windows.Forms.Button();
            this.idLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.cusidBox = new System.Windows.Forms.TextBox();
            this.sessionBox = new System.Windows.Forms.TextBox();
            this.staffschBox = new System.Windows.Forms.TextBox();
            this.memcheck = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.search = new System.Windows.Forms.Button();
            this.Submit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.typepayment = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // AvLabel
            // 
            this.AvLabel.AutoSize = true;
            this.AvLabel.BackColor = System.Drawing.Color.Transparent;
            this.AvLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvLabel.Location = new System.Drawing.Point(754, 418);
            this.AvLabel.Name = "AvLabel";
            this.AvLabel.Size = new System.Drawing.Size(246, 29);
            this.AvLabel.TabIndex = 12;
            this.AvLabel.Text = "Session Availabilty";
            this.AvLabel.Click += new System.EventHandler(this.AvLabel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(255, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Checking with Cusomer Email: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Check with CusomerID: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(197, 418);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 29);
            this.label4.TabIndex = 45;
            this.label4.Text = "Staff Availabilty";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(443, 624);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 44;
            this.label3.Text = "Date:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(750, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 20);
            this.label5.TabIndex = 50;
            this.label5.Text = "Session ID:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(745, 253);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(166, 20);
            this.label13.TabIndex = 49;
            this.label13.Text = "Payment Required :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(750, 181);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 20);
            this.label8.TabIndex = 48;
            this.label8.Text = "Staff  ID:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(750, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 20);
            this.label7.TabIndex = 47;
            this.label7.Text = "Customer ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(932, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 29);
            this.label6.TabIndex = 46;
            this.label6.Text = "Booking";
            // 
            // idBox
            // 
            this.idBox.Location = new System.Drawing.Point(273, 13);
            this.idBox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.idBox.Name = "idBox";
            this.idBox.Size = new System.Drawing.Size(217, 27);
            this.idBox.TabIndex = 51;
            // 
            // emailBox
            // 
            this.emailBox.Location = new System.Drawing.Point(273, 98);
            this.emailBox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(217, 27);
            this.emailBox.TabIndex = 52;
            // 
            // checkId
            // 
            this.checkId.BackColor = System.Drawing.Color.LimeGreen;
            this.checkId.Location = new System.Drawing.Point(510, 13);
            this.checkId.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.checkId.Name = "checkId";
            this.checkId.Size = new System.Drawing.Size(87, 35);
            this.checkId.TabIndex = 53;
            this.checkId.Text = "Check";
            this.checkId.UseVisualStyleBackColor = false;
            this.checkId.Click += new System.EventHandler(this.checkId_Click);
            // 
            // checkEmail
            // 
            this.checkEmail.BackColor = System.Drawing.Color.LimeGreen;
            this.checkEmail.Location = new System.Drawing.Point(510, 94);
            this.checkEmail.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.checkEmail.Name = "checkEmail";
            this.checkEmail.Size = new System.Drawing.Size(87, 35);
            this.checkEmail.TabIndex = 54;
            this.checkEmail.Text = "Check";
            this.checkEmail.UseVisualStyleBackColor = false;
            this.checkEmail.Click += new System.EventHandler(this.checkEmail_Click);
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.BackColor = System.Drawing.Color.Transparent;
            this.idLabel.Location = new System.Drawing.Point(269, 58);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(227, 20);
            this.idLabel.TabIndex = 55;
            this.idLabel.Text = "[....................................................]";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.BackColor = System.Drawing.Color.Transparent;
            this.emailLabel.Location = new System.Drawing.Point(269, 148);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(227, 20);
            this.emailLabel.TabIndex = 56;
            this.emailLabel.Text = "[....................................................]";
            // 
            // cusidBox
            // 
            this.cusidBox.Location = new System.Drawing.Point(892, 94);
            this.cusidBox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cusidBox.Name = "cusidBox";
            this.cusidBox.Size = new System.Drawing.Size(222, 27);
            this.cusidBox.TabIndex = 57;
            // 
            // sessionBox
            // 
            this.sessionBox.Location = new System.Drawing.Point(892, 135);
            this.sessionBox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.sessionBox.Name = "sessionBox";
            this.sessionBox.Size = new System.Drawing.Size(222, 27);
            this.sessionBox.TabIndex = 58;
            // 
            // staffschBox
            // 
            this.staffschBox.Location = new System.Drawing.Point(892, 174);
            this.staffschBox.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.staffschBox.Name = "staffschBox";
            this.staffschBox.Size = new System.Drawing.Size(222, 27);
            this.staffschBox.TabIndex = 59;
            // 
            // memcheck
            // 
            this.memcheck.AutoSize = true;
            this.memcheck.BackColor = System.Drawing.Color.Transparent;
            this.memcheck.Location = new System.Drawing.Point(921, 253);
            this.memcheck.Name = "memcheck";
            this.memcheck.Size = new System.Drawing.Size(227, 20);
            this.memcheck.TabIndex = 60;
            this.memcheck.Text = "[....................................................]";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarTrailingForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.Location = new System.Drawing.Point(510, 620);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(233, 27);
            this.dateTimePicker1.TabIndex = 61;
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.LimeGreen;
            this.search.Location = new System.Drawing.Point(770, 618);
            this.search.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(87, 35);
            this.search.TabIndex = 62;
            this.search.Text = "Check";
            this.search.UseVisualStyleBackColor = false;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // Submit
            // 
            this.Submit.BackColor = System.Drawing.Color.LimeGreen;
            this.Submit.Location = new System.Drawing.Point(865, 287);
            this.Submit.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(87, 35);
            this.Submit.TabIndex = 63;
            this.Submit.Text = "Book ";
            this.Submit.UseVisualStyleBackColor = false;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(1027, 287);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 35);
            this.button1.TabIndex = 64;
            this.button1.Text = "Exit ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(646, 452);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(600, 132);
            this.dataGridView1.TabIndex = 65;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(12, 452);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(600, 132);
            this.dataGridView3.TabIndex = 66;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 173);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(600, 176);
            this.dataGridView2.TabIndex = 67;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(745, 221);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(166, 20);
            this.label9.TabIndex = 68;
            this.label9.Text = "Payment Required :";
            // 
            // typepayment
            // 
            this.typepayment.Location = new System.Drawing.Point(926, 219);
            this.typepayment.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.typepayment.Name = "typepayment";
            this.typepayment.Size = new System.Drawing.Size(211, 27);
            this.typepayment.TabIndex = 69;
            // 
            // Bookingform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1281, 664);
            this.Controls.Add(this.typepayment);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.search);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.memcheck);
            this.Controls.Add(this.staffschBox);
            this.Controls.Add(this.sessionBox);
            this.Controls.Add(this.cusidBox);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.checkEmail);
            this.Controls.Add(this.checkId);
            this.Controls.Add(this.emailBox);
            this.Controls.Add(this.idBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AvLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Gill Sans MT Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Bookingform";
            this.Text = "Bookingform";
            this.Load += new System.EventHandler(this.Bookingform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AvLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox idBox;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.Button checkId;
        private System.Windows.Forms.Button checkEmail;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.TextBox cusidBox;
        private System.Windows.Forms.TextBox sessionBox;
        private System.Windows.Forms.TextBox staffschBox;
        private System.Windows.Forms.Label memcheck;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox typepayment;
    }
}