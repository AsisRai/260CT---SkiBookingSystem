﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;




namespace Group_AJR___SBC_Booking_System.checkin
{
    public partial class checkinform : Form
    {
        int memtype;
        bool isreg = false;
        SqlConnection con;

        public checkinform()
        {
            InitializeComponent();
        }

        private void cusidsearch_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDBFilename=|DataDirectory|\SBCDatabaseV2.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand checkid = new SqlCommand();
            checkid.CommandText = "select * from [Bookingtable]";
            checkid.Connection = con;

            SqlDataReader rd = checkid.ExecuteReader();

            while (rd.Read())
            {
                if (rd[1].ToString() == cusidtxtbox.Text)
                {
                    isreg = true;
                }

                    if (isreg == true)
                    {
                        if (rd[4].ToString() == "1")
                        {
                            checkinornot.Text = "Customer is checked in";
                            memtype = 1;
                        }

                        //else if (rd[3].ToString() == "2")
                        //{
                            //checkinornot.Text = "Customer is checked in";
                            //memtype = 1;

                       // }
                        else
                        {
                            checkinornot.Text = "Customer is not checked in";
                            memtype = 2;

                        }

                    }
            }


            if (isreg == true)
            {
                customeridbox2.Text = cusidtxtbox.Text;
                resultfound.Text = "Customer is registered";
            }
            else
            {
                resultfound.Text = "Customer is not registered";
            }

            isreg = false;
            con.Close();

            //SqlDataReader rd = checkid.ExecuteReader();
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDBFilename=|DataDirectory|\SBCDatabaseV2.mdf;Integrated Security=True;Connect Timeout=30");
            SqlDataAdapter checkup = new SqlDataAdapter("SELECT * FROM [Bookingtable] WHERE customerID ='" + cusidtxtbox.Text + "'", con); //this will get all the data
            DataTable sd = new DataTable();

            checkup.Fill(sd);
            dataGridView1.DataSource = sd;
                
        }

        private void checkinform_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            MainUIform main = new MainUIform();
            main.Show();
        }

        private void checkin_Click(object sender, EventArgs e)
        {
            using (SqlConnection Connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDBFilename=|DataDirectory|\SBCDatabaseV2.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                try
                {
                    Connection.Open();
                    SqlCommand cmd = new SqlCommand(@"INSERT INTO Bookingtable ([customerID], [checkedin]) VALUES (@customerID, @checkedin);", Connection);
                    cmd.Parameters.AddWithValue("@customerID", customeridbox2.Text);
                    cmd.Parameters.AddWithValue("@checkedin", checkBox1.Checked);

                    int i = cmd.ExecuteNonQuery();
                    Connection.Close();

                    if (i == 1)
                    {
                        MessageBox.Show("Customer has been check-in");
                        getPrimaryKey();

                        customeridbox2.Clear();
                        cusidtxtbox.Clear();
                    }

                    else
                    {
                        MessageBox.Show("Customer couln't be added, try again");
                    }

                }
                catch (Exception ex)
                    {
                        MessageBox.Show("Unexpected Error has occured:" + ex.Message);

                    }
            }
        }
        private void getPrimaryKey()
        {
            using (SqlConnection Connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDBFilename=|DataDirectory|\SBCDatabaseV2;Integrated Security=True;Connect Timeout=30"))
            {
                try
                {
                    Connection.Open();
                    SqlCommand cmd = new SqlCommand(@"SELECT MAX(Id)+1 FROM Bookingtable;", Connection);
                    Connection.Close();

                }

                catch (Exception ex)
                {
                    MessageBox.Show("Unexpected Error has occured: " + ex.Message);
                }
            }
        }
    }
}




